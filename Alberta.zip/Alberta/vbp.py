#!/usr/bin/env python
# coding: utf-8

# In[1]:


# !pip install -r requirements.txt 


# In[2]:


# !wget https://raw.githubusercontent.com/milvus-io/milvus/master/deployments/docker/standalone/docker-compose.yml -O docker-compose.yml<br>
# !sudo docker-compose up -d


# In[21]:


from pymilvus import connections
import psycopg2

from pymilvus import Collection, CollectionSchema, FieldSchema, DataType

from sentence_transformers import SentenceTransformer
import pandas as pd
from sklearn.preprocessing import normalize

from pymilvus import Collection, CollectionSchema, FieldSchema, DataType

from flask import Flask, request
from flask_cors import CORS, cross_origin

from OpenSSL import SSL


# ---

# ## Database Connections

# In[22]:


connections.connect(host='34.171.122.212', port='19530')
conn = psycopg2.connect(database="alpha_alberta", host='35.203.122.7', port='5432', user='my_alpha_user', password='alpha_alberta@') # postgres
print("CONNECTION ====",conn)


# ## Global Variables

# In[23]:


TABLE_NAME = "Skills_Embd"
field_name = "Skills"

TABLE_NAME_1 = "Skills_Embd"
field_name_1 = "Skills"

TABLE_NAME_2 = "Embds"
field_name_2 = "Mix_Fields"

TABLE_NAME_3 = "Biz_Embds"
field_name_3 = "Biz"

TABLE_NAME_4 = "Ppl_Embds"
field_name_4 = "Ppl"

TABLE_NAME_5 = "cmt_Embds"
field_name_5 = "cmt"

TABLE_NAME_6 = "doc_Embds"
field_name_6 = "doc"

# paraphrase-mpnet-base-v2 
# multi-qa-mpnet-base-dot-v1
# all-with_prefix-t5-base-v1
# all-mpnet-base-v2
# all-MiniLM-L6-v2
# paraphrase-MiniLM-L6-v2 **BEST**
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
cursor = conn.cursor()

search_params = {"metric_type": "L2", "params": {"nprobe": 10}}


# ## Column Names

# In[14]:


# cursor = conn.cursor()
# cursor.execute("select relname from pg_class where relkind='r' and relname !~ '^(pg_|sql_)';")
# print(cursor.fetchall())


# In[15]:


# print('challenge_creator_challengestatement:')
# print('-'*50)
# cursor.execute("Select * FROM challenge_creator_challengestatement LIMIT 0")
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)

# print('='*50)

# print('api_user:')
# print('-'*50)
# cursor.execute("Select * FROM api_user LIMIT 0")
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)

# print('='*50)

# print('api_personalinformation:')
# print('-'*50)
# cursor.execute("Select * FROM api_personalinformation LIMIT 0")
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)

# print('='*50)

# print('api_personallabequipments:')
# print('-'*50)
# cursor.execute("Select * FROM api_personallabequipments LIMIT 0")
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)

# print('='*50)

# print('api_businessinformation:')
# print('-'*50)
# cursor.execute("Select * FROM api_businessinformation LIMIT 0")
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)

# print('='*50)

# print('api_businesslabequipments:')
# print('-'*50)
# cursor.execute("Select * FROM api_businesslabequipments LIMIT 0")
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)

# print('='*50)

# print('api_businesslocation:')
# print('-'*50)
# cursor.execute("Select * FROM api_businesslocation LIMIT 0") 
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)

# print('='*50)

# print('challenge_creator_comment:')
# print('-'*50)
# cursor.execute("Select * FROM challenge_creator_comment LIMIT 0") 
# colnames = [desc[0] for desc in cursor.description]
# print(colnames)


# ---

# ## Recommendations

# In[24]:


def update_rcmd():
    
    try:
        collection = Collection(name = TABLE_NAME)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True) #, auto_id=True)
    skills = FieldSchema(name = field_name, dtype = DataType.FLOAT_VECTOR, dim = 384)
    schema = CollectionSchema(fields = [pid, skills], description = "example collection")
    collection = Collection(name = TABLE_NAME, schema = schema)
    
    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name=field_name, index_params=index_param)
    
#   ['id', 'challenge_title', 'challenge_description', 'challenge_location', 'challenge_state', 
#    'challenge_city', 'skills', 'status_type', 'post_type', 'is_active', 'is_archieve', 
#    'is_student_required', 'created_at', 'challenge_end_date', 'updated_at', 
#    'created_at_time', 'updated_at_time', 'company_name_id', 'user_id'] 
    
    cursor.execute("Select id, skills from challenge_creator_challengestatement")
    rows_pos = cursor.fetchall()
    
    lst_pid, lst_skills = [], []
    for i, j in rows_pos:
        lst_pid.append(i)
        lst_skills.append(j)
    
    if len(lst_skills) != 0:
        sentence_embeddings = model.encode(lst_skills)
        sentence_embeddings = normalize(sentence_embeddings)
        print(type(sentence_embeddings))

        em = list(sentence_embeddings)
        mr = collection.insert([lst_pid, em])
    else:
        print("There is no Data")


# In[25]:


update_rcmd()


# In[26]:


def query_rcmd(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
 
    search_skills = q
    
    embed = model.encode(search_skills)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()
    
    collection = Collection(TABLE_NAME)
    collection.load()
    results = collection.search(query_embeddings, field_name, param=search_params, limit=100, expr=None)
    
    recommendation = []
    for result in results[0]:
        print(result.distance)
        if result.distance < 1.50:
    
#           ['id', 'challenge_title', 'challenge_description', 'challenge_location', 'challenge_state', 
#            'challenge_city', 'skills', 'status_type', 'post_type', 'is_active', 'is_archieve', 
#            'is_student_required', 'created_at', 'challenge_end_date', 'updated_at', 
#            'created_at_time', 'updated_at_time', 'company_name_id', 'user_id']       

            sql = "select * from challenge_creator_challengestatement where id = " + str(result.id) + ";"
            cursor.execute(sql)
            rows = cursor.fetchall()

            get_user_name = "select username from api_user where id =" + str(rows[0][-1]) + ";"
            cursor.execute(get_user_name)
            fetch_user_name = cursor.fetchall()
            fetch_user_name = fetch_user_name[0][0]

            if rows[0][-2] is not None:
                get_company_name = "select company_name from api_businessinformation where id =" + str(rows[0][-2]) + ";"
                cursor.execute(get_user_name)
                fetch_company_name = cursor.fetchall()
                fetch_company_name = fetch_company_name[0][0]
            else:
                fetch_company_name = None

            if len(rows):
                recommendation.append({'id' : rows[0][0], 
                                       'challenge_title': rows[0][1],
                                       'challenge_description': rows[0][2],
                                       'challenge_location': rows[0][3],
                                       'challenge_state': rows[0][4],
                                       'challenge_city': rows[0][5],
                                       'skills': rows[0][6],
                                       'status_type': rows[0][7],
                                       'post_type': rows[0][8],
                                       'is_active': rows[0][9],
                                       'is_archieve': rows[0][10],
                                       'is_student_required': rows[0][11],
                                       'created_at': rows[0][12],
                                       'challenge_end_date': rows[0][13],
                                       'updated_at': rows[0][14],
                                       'created_at_time': rows[0][15],
                                       'updated_at_time': rows[0][16],
                                       'company_name_id': rows[0][17],
                                       'user_id': rows[0][18],
                                       'user_name': fetch_user_name,
                                       'company_name': fetch_company_name})
    
    return recommendation


# In[39]:


rcmd = query_rcmd('Golang php react')
for i, j in enumerate(rcmd):
    
    print(i, "-->")
    print('='*25)
    
    for m, n in j.items():
        print(m, ':', n)

#     if i == 1:
#         break


# ## Student Recommendations

# In[28]:


def update_stdrcmd():
    
    try:
        collection = Collection(name = TABLE_NAME_1)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True) #, auto_id=True)
    skills = FieldSchema(name = field_name_1, dtype = DataType.FLOAT_VECTOR, dim = 384)
    schema = CollectionSchema(fields = [pid, skills], description = "example collection")
    collection = Collection(name = TABLE_NAME_1, schema = schema)
    
    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name=field_name_1, index_params=index_param)
    
#   ['id', 'challenge_title', 'challenge_description', 'challenge_location', 'challenge_state', 
#    'challenge_city', 'skills', 'status_type', 'post_type', 'is_active', 'is_archieve', 
#    'is_student_required', 'created_at', 'challenge_end_date', 'updated_at', 
#    'created_at_time', 'updated_at_time', 'company_name_id', 'user_id'] 
    
    cursor.execute("Select id, skills from challenge_creator_challengestatement")
    rows_pos = cursor.fetchall()
    
    lst_pid, lst_skills = [], []
    for i, j in rows_pos:
        lst_pid.append(i)
        lst_skills.append(j)
    
    if len(lst_skills) != 0:
        sentence_embeddings = model.encode(lst_skills)
        sentence_embeddings = normalize(sentence_embeddings)
        print(type(sentence_embeddings))

        em = list(sentence_embeddings)
        mr = collection.insert([lst_pid, em])
    else:
        print("There is no Data")


# In[29]:


# update_stdrcmd()


# In[30]:


def query_stdrcmd(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
 
    search_skills = q
    
    embed = model.encode(search_skills)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()
    
    collection = Collection(TABLE_NAME_1)
    collection.load()
    results = collection.search(query_embeddings, field_name_1, param=search_params, limit=100, expr=None)
    
    recommendation1, recommendation2 = [], []
    for result in results[0]:
        
        if result.distance < 1.50:
    
    #       ['id', 'challenge_title', 'challenge_description', 'challenge_location', 'challenge_state', 
    #        'challenge_city', 'skills', 'status_type', 'post_type', 'is_active', 'is_archieve', 
    #        'is_student_required', 'created_at', 'challenge_end_date', 'updated_at', 
    #        'created_at_time', 'updated_at_time', 'company_name_id', 'user_id']       

            sql = "select * from challenge_creator_challengestatement AS ccc where id = " + str(result.id) + ";"
            cursor.execute(sql)
            rows = cursor.fetchall()

            if rows[0][11] == True:

                get_user_name = "select username from api_user where id =" + str(rows[0][-1]) + ";"
                cursor.execute(get_user_name)
                fetch_user_name = cursor.fetchall()
                fetch_user_name = fetch_user_name[0][0]

                if rows[0][-2] is not None:
                    get_company_name = "select company_name from api_businessinformation where id =" + str(rows[0][-2]) + ";"
                    cursor.execute(get_user_name)
                    fetch_company_name = cursor.fetchall()
                    fetch_company_name = fetch_company_name[0][0]
                else:
                    fetch_company_name = None

                if len(rows):
                    recommendation1.append({'id' : rows[0][0], 
                                           'challenge_title': rows[0][1],
                                           'challenge_description': rows[0][2],
                                           'challenge_location': rows[0][3],
                                           'challenge_state': rows[0][4],
                                           'challenge_city': rows[0][5],
                                           'skills': rows[0][6],
                                           'status_type': rows[0][7],
                                           'post_type': rows[0][8],
                                           'is_active': rows[0][9],
                                           'is_archieve': rows[0][10],
                                           'is_student_required': rows[0][11],
                                           'created_at': rows[0][12],
                                           'challenge_end_date': rows[0][13],
                                           'updated_at': rows[0][14],
                                           'created_at_time': rows[0][15],
                                           'updated_at_time': rows[0][16],
                                           'company_name_id': rows[0][17],
                                           'user_id': rows[0][18],
                                           'user_name': fetch_user_name,
                                           'company_name': fetch_company_name})


            if rows[0][11] == False:

                get_user_name = "select username from api_user where id =" + str(rows[0][-1]) + ";"
                cursor.execute(get_user_name)
                fetch_user_name = cursor.fetchall()
                fetch_user_name = fetch_user_name[0][0]

                if rows[0][-2] is not None:
                    get_company_name = "select company_name from api_businessinformation where id =" + str(rows[0][-2]) + ";"
                    cursor.execute(get_user_name)
                    fetch_company_name = cursor.fetchall()
                    fetch_company_name = fetch_company_name[0][0]
                else:
                    fetch_company_name = None

                if len(rows):
                    recommendation2.append({'id' : rows[0][0], 
                                           'challenge_title': rows[0][1],
                                           'challenge_description': rows[0][2],
                                           'challenge_location': rows[0][3],
                                           'challenge_state': rows[0][4],
                                           'challenge_city': rows[0][5],
                                           'skills': rows[0][6],
                                           'status_type': rows[0][7],
                                           'post_type': rows[0][8],
                                           'is_active': rows[0][9],
                                           'is_archieve': rows[0][10],
                                           'is_student_required': rows[0][11],
                                           'created_at': rows[0][12],
                                           'challenge_end_date': rows[0][13],
                                           'updated_at': rows[0][14],
                                           'created_at_time': rows[0][15],
                                           'updated_at_time': rows[0][16],
                                           'company_name_id': rows[0][17],
                                           'user_id': rows[0][18],
                                           'user_name': fetch_user_name,
                                           'company_name': fetch_company_name})
                
    recommendation = recommendation1 + recommendation2

    return recommendation


# In[31]:


# rcmd = query_stdrcmd('django react html')
# for i, j in enumerate(rcmd):
    
#     print(i, "-->")
#     print('='*25)
    
#     for m, n in j.items():
#         print(m, ':', n)

#     if i == 1:
#         break


# ---

# ## Search

# In[32]:


def update_search():
    
    try:
        collection = Collection(name = TABLE_NAME_2)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True) #, auto_id=True)
    embds = FieldSchema(name = field_name_2, dtype = DataType.FLOAT_VECTOR, dim = 384)
    schema = CollectionSchema(fields = [pid, embds], description = "This table contails embeddings \
                              of mixed fields i.e. id, challenge_title, challenge_description, \
                              challenge_location and skills")
    collection = Collection(name = TABLE_NAME_2, schema = schema)
    
    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name=field_name_2, index_params=index_param)
    
#   ['id', 'challenge_title', 'challenge_description', 'challenge_location', 'challenge_state', 
#    'challenge_city', 'skills', 'status_type', 'post_type', 'is_active', 'is_archieve', 
#    'is_student_required', 'created_at', 'challenge_end_date', 'updated_at', 
#    'created_at_time', 'updated_at_time', 'company_name_id', 'user_id']     
    
    cursor.execute("Select id, challenge_title, skills, challenge_location, challenge_state, challenge_city, \
                    challenge_description from challenge_creator_challengestatement")
    rows_pos = cursor.fetchall()
    
    lst_pid, lst_mix = [], []
    for i in rows_pos:
        lst_pid.append(i[0])
        lst_mix.append(i[1] + ' ' + i[2] + ' ' + i[3] + ' ' + i[4] + ' ' + i[5] + ' ' + i[6])
    
    if len(lst_mix) != 0:
        sentence_embeddings = model.encode(lst_mix)
        sentence_embeddings = normalize(sentence_embeddings)
        print(type(sentence_embeddings))

        em = list(sentence_embeddings)
        mr = collection.insert([lst_pid, em])
    else:
        print("There is no Data")


# In[33]:


# update_search()


# In[34]:


def query_search(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
 
    search_skills = q
    
    embed = model.encode(search_skills)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()
    
    collection = Collection(TABLE_NAME_2)
    collection.load()
    results = collection.search(query_embeddings, field_name_2, param=search_params, limit=100, expr=None)
    
    search = []
    for result in results[0]:
        
        if result.distance < 1.8:
        
    #       ['id', 'challenge_title', 'challenge_description', 'challenge_location', 'challenge_state', 
    #        'challenge_city', 'skills', 'status_type', 'post_type', 'is_active', 'is_archieve', 
    #        'is_student_required', 'created_at', 'challenge_end_date', 'updated_at', 
    #        'created_at_time', 'updated_at_time', 'company_name_id', 'user_id']   

            sql = "select * from challenge_creator_challengestatement where id = " + str(result.id) + ";"
            cursor.execute(sql)
            rows = cursor.fetchall()

            get_user_name = "select username from api_user where id =" + str(rows[0][-1]) + ";"
            cursor.execute(get_user_name)
            fetch_user_name = cursor.fetchall()
            fetch_user_name = fetch_user_name[0][0]

            if rows[0][-2] is not None:
                get_company_name = "select company_name from api_businessinformation where id =" + str(rows[0][-2]) + ";"
                cursor.execute(get_user_name)
                fetch_company_name = cursor.fetchall()
                fetch_company_name = fetch_company_name[0][0]
            else:
                fetch_company_name = None

            if len(rows):
                search.append({'id' : rows[0][0], 
                               'challenge_title': rows[0][1],
                               'challenge_description': rows[0][2],
                               'challenge_location': rows[0][3],
                               'challenge_state': rows[0][4],
                               'challenge_city': rows[0][5],
                               'skills': rows[0][6],
                               'status_type': rows[0][7],
                               'post_type': rows[0][8],
                               'is_active': rows[0][9],
                               'is_archieve': rows[0][10],
                               'is_student_required': rows[0][11],
                               'created_at': rows[0][12],
                               'challenge_end_date': rows[0][13],
                               'updated_at': rows[0][14],
                               'created_at_time': rows[0][15],
                               'updated_at_time': rows[0][16],
                               'company_name_id': rows[0][17],
                               'user_id': rows[0][18],
                               'user_name': fetch_user_name,
                               'company_name': fetch_company_name})
    
    return search


# In[37]:


search = query_search('django react html')
for i, j in enumerate(search):
    
    print(i, "-->")
    print('='*25)
    
    for m, n in j.items():
        print(m, ':', n)
    
    if i == 1:
        break


# ---

# ## Business

# In[4]:


def update_biz():
    
    try:
        collection = Collection(name = TABLE_NAME_3)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True) #, auto_id=True)
    biz = FieldSchema(name = field_name_3, dtype = DataType.FLOAT_VECTOR, dim = 384)
    schema = CollectionSchema(fields = [pid, biz], description = "example collection")
    collection = Collection(name = TABLE_NAME_3, schema = schema)
    
    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name=field_name_3, index_params=index_param)
    
#   ['id', 'userid', 'company_name', 'company_website', 'company_description', 'company_email', 
#    'company_phone', 'company_classification', 'company_type', 'gross_revenue', 'invite_through_company', 
#    'years_in_business', 'start_date', 'end_date', 'created_at', 'modified_at', 'user_id', 'company_headcount']

#   ['id', 'company_address_line_1', 'company_address_line_2', 'company_city', 'company_state', 
#    'company_country', 'zip_code', 'created_at', 'modified_at', 'business_id', 'user_id']
    
    cursor.execute("Select id, company_name, company_description, company_classification, company_type, \
                    company_website, company_email, company_phone from api_businessinformation")
    rows_pos = cursor.fetchall()
    
    lst_pid, lst_biz = [], []
    for i in rows_pos:
        
        lst_pid.append(i[0])
        
        s = ''
        for m in i[1:]:

            if m is not None:
                s = s + ' ' + str(m)
        
        cursor.execute("Select company_address_line_1, company_address_line_2, company_city, \
                        company_state, company_country, zip_code from api_businesslocation \
                        WHERE business_id = {};".format(i[0]))
        rows_loc = cursor.fetchall()
        
        for j in rows_loc:
            for n in j:
                if n is not None:
                    s = s + ' ' + str(n)
        
        lst_biz.append(s)
    
    if len(lst_biz) != 0:
        sentence_embeddings = model.encode(lst_biz)
        sentence_embeddings = normalize(sentence_embeddings)
        print(type(sentence_embeddings))

        em = list(sentence_embeddings)
        mr = collection.insert([lst_pid, em])
    else:
        print("There is no Data")


# In[5]:


# update_biz()


# In[147]:


def query_biz(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
 
    search_skills = q
    
    embed = model.encode(search_skills)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()
    
    collection = Collection(TABLE_NAME_3)
    collection.load()
    results = collection.search(query_embeddings, field_name_3, param=search_params, limit=100, expr=None)
    
    biz = []
    for result in results[0]:
        
        if result.distance < 1.5:
        
#           ['id', 'userid', 'company_name', 'company_website', 'company_description', 'company_email', 
#            'company_phone', 'company_classification', 'company_type', 'gross_revenue', 'invite_through_company', 
#            'years_in_business', 'start_date', 'end_date', 'created_at', 'modified_at', 'user_id', 'company_headcount']

#           ['id', 'company_address_line_1', 'company_address_line_2', 'company_city', 'company_state', 
#            'company_country', 'zip_code', 'created_at', 'modified_at', 'business_id', 'user_id']

            sql = "select * from api_businessinformation where id = " + str(result.id) + ";"
            cursor.execute(sql)
            rows = cursor.fetchall()

            sql = "select * from api_businesslocation where business_id = " + str(result.id) + ";"
            cursor.execute(sql)
            rows_loc = cursor.fetchall()

            loc = []
            for i in rows_loc:
                loc.append({'id': i[0],
                            'company_address_line_1': i[1],
                            'company_address_line_2': i[2],
                            'company_city': i[3],
                            'company_state': i[4],
                            'company_country': i[5],
                            'zip_code': i[6],
                            'created_at': i[7],
                            'modified_at': i[8],
                            'business_id': i[9],
                            'user_id': i[10]})

            if len(rows):
                biz.append({'id' : rows[0][0], 
                            'userid': rows[0][1],
                            'company_name': rows[0][2],
                            'company_website': rows[0][3],
                            'company_description': rows[0][4],
                            'company_email': rows[0][5],
                            'company_phone': rows[0][6],
                            'company_classification': rows[0][7],
                            'company_type': rows[0][8],
                            'gross_revenue': rows[0][9],
                            'invite_through_company': rows[0][10],
                            'years_in_business': rows[0][11],
                            'start_date': rows[0][12],
                            'end_date': rows[0][13],
                            'created_at': rows[0][14],
                            'modified_at': rows[0][15],
                            'user_id': rows[0][16],
                            'company_headcount': rows[0][17],
                            'locations': loc})

    return biz


# In[149]:


# biz = query_biz('Kolkata')
# for i, j in enumerate(biz):
    
#     print(i, "-->")
#     print('='*25)
    
#     for m, n in j.items():
        
#         if m == 'locations':
            
#             print(m, ':')
            
#             for k, l in enumerate(n):
                
#                 print('        ', k, "-->")
#                 print('        ', '='*25)
                
#                 for x, y in l.items():
#                     print('        ', x, ':', y)
                
#         else:
#             print(m, ':', n)
    
#     if i == 1:
#         break


# ---

# ## People

# In[26]:


def update_ppl():
    
    try:
        collection = Collection(name = TABLE_NAME_4)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True) #, auto_id=True)
    ppl = FieldSchema(name = field_name_4, dtype = DataType.FLOAT_VECTOR, dim = 384)
    schema = CollectionSchema(fields = [pid, ppl], description = "example collection")
    collection = Collection(name = TABLE_NAME_4, schema = schema)
    
    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name=field_name_4, index_params=index_param)
    
#   ['id', 'first_name', 'last_name', 'personal_email', 'personal_skills', 'job_title', 'headline', 
#    'bio', 'office_phone', 'personal_phone', 'address_line_1', 'address_line_2', 'profile_picture', 
#    'city', 'state', 'country', 'zip_code', 'is_student', 'created_at', 'modified_at', 'user_id']
    
    cursor.execute("Select id, first_name, last_name, personal_skills, job_title, \
                    headline, bio, personal_phone, address_line_1, address_line_2, \
                    city, state, country, personal_email, office_phone, zip_code from api_personalinformation")
    rows_pos = cursor.fetchall()
    
    lst_pid, lst_ppl = [], []
    for i in rows_pos:
        
        lst_pid.append(i[0])
        
        s = ''
        for m in i[1:]:

            if m is not None:
                s = s + ' ' + str(m)
        
        lst_ppl.append(s)
    
    if len(lst_ppl) != 0:
        sentence_embeddings = model.encode(lst_ppl)
        sentence_embeddings = normalize(sentence_embeddings)
        print(type(sentence_embeddings))

        em = list(sentence_embeddings)
        mr = collection.insert([lst_pid, em])
    else:
        print("There is no Data")


# In[27]:


# update_ppl()


# In[160]:


def query_ppl(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
 
    search_skills = q
    
    embed = model.encode(search_skills)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()
    
    collection = Collection(TABLE_NAME_4)
    collection.load()
    results = collection.search(query_embeddings, field_name_4, param=search_params, limit=100, expr=None)
    
    ppl = []
    for result in results[0]:   
        
        if result.distance < 1.5:
        
#           ['id', 'first_name', 'last_name', 'personal_email', 'personal_skills', 'job_title', 'headline', 
#            'bio', 'office_phone', 'personal_phone', 'address_line_1', 'address_line_2', 'profile_picture', 
#            'city', 'state', 'country', 'zip_code', 'is_student', 'created_at', 'modified_at', 'user_id']

            sql = "select * from api_personalinformation where id = " + str(result.id) + ";"
            cursor.execute(sql)
            rows = cursor.fetchall()

            if len(rows):
                ppl.append({'id' : rows[0][0], 
                            'first_name': rows[0][1],
                            'last_name': rows[0][2],
                            'personal_email': rows[0][3],
                            'personal_skills': rows[0][4],
                            'job_title': rows[0][5],
                            'headline': rows[0][6],
                            'bio': rows[0][7],
                            'office_phone': rows[0][8],
                            'personal_phone': rows[0][9],
                            'address_line_1': rows[0][10],
                            'address_line_2': rows[0][11],
                            'profile_picture': rows[0][12],
                            'city': rows[0][13], 
                            'state': rows[0][14], 
                            'country': rows[0][15], 
                            'zip_code': rows[0][16], 
                            'is_student': rows[0][17],
                            'created_at': rows[0][18], 
                            'modified_at': rows[0][19], 
                            'user_id': rows[0][20]})
    
    return ppl


# In[161]:


# ppl = query_ppl('software developer')
# for i, j in enumerate(ppl):
    
#     print(i, "-->")
#     print('='*25)
    
#     for m, n in j.items():
#         print(m, ':', n)
    
#     if i == 1:
#         break


# ## Comment

# In[165]:


def update_cmt():
    
    try:
        collection = Collection(name = TABLE_NAME_5)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True) #, auto_id=True)
    oid = FieldSchema(name = "oid", dtype = DataType.INT64)
    cmt = FieldSchema(name = field_name_5, dtype = DataType.FLOAT_VECTOR, dim = 384)
    schema = CollectionSchema(fields = [pid, oid, cmt], description = "Comment embeddings with its object_id and id")
    collection = Collection(name = TABLE_NAME_5, schema = schema)
    
    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name=field_name_5, index_params=index_param)
    
#   ['id', 'object_id', 'user_comment', 'created_at', 'updated_at', 'created_at_time', 
#    'updated_at_time', 'commented_by_id', 'company_name_id', 'content_type_id', 'parent_id']
    
    cursor.execute("Select id, object_id, user_comment from challenge_creator_comment")
    rows_pos = cursor.fetchall()
    
    lst_pid, lst_oid, lst_cmt = [], [], []
    for i in rows_pos:
        
        lst_pid.append(i[0])  
        lst_oid.append(i[1])
        lst_cmt.append(i[2])
    
    if len(lst_cmt) != 0:
        sentence_embeddings = model.encode(lst_cmt)
        sentence_embeddings = normalize(sentence_embeddings)
        print(type(sentence_embeddings))

        em = list(sentence_embeddings)
        mr = collection.insert([lst_pid, lst_oid, em])
    else:
        print("There is no Data")


# In[166]:


# update_cmt()


# In[30]:


def query_cmt(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
 
    search_skills = q
    
    embed = model.encode(search_skills)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()
    
    collection = Collection(TABLE_NAME_5)
    collection.load()
    results = collection.search(query_embeddings, field_name_5, param=search_params, limit=1000, expr=None)
    
    cmt = []
    for result in results[0]: 
        
        if result.distance < 1.5:
            
#           ['id', 'object_id', 'user_comment', 'created_at', 'updated_at', 'created_at_time', 
#            'updated_at_time', 'commented_by_id', 'company_name_id', 'content_type_id', 'parent_id']

#           ['id', 'challenge_title', 'challenge_description', 'challenge_location', 'challenge_state', 
#            'challenge_city', 'skills', 'status_type', 'post_type', 'is_active', 'is_archieve', 
#            'is_student_required', 'created_at', 'challenge_end_date', 'updated_at', 
#            'created_at_time', 'updated_at_time', 'company_name_id', 'user_id']  

            cmt_sql = "select * from challenge_creator_comment where id = " + str(result.id) + ";"
            cursor.execute(cmt_sql)
            rows_cmt = cursor.fetchall()

            sql = "select * from challenge_creator_challengestatement where id = {};".format(rows_cmt[0][1])
            cursor.execute(sql)
            rows = cursor.fetchall()

            if len(rows):
                cmt.append({'id' : rows[0][0], 
                            'challenge_title': rows[0][1],
                            'challenge_description': rows[0][2],
                            'challenge_location': rows[0][3],
                            'challenge_state': rows[0][4],
                            'challenge_city': rows[0][5],
                            'skills': rows[0][6],
                            'status_type': rows[0][7],
                            'post_type': rows[0][8],
                            'is_active': rows[0][9],
                            'is_archieve': rows[0][10],
                            'is_student_required': rows[0][11],
                            'created_at': rows[0][12],
                            'challenge_end_date': rows[0][13],
                            'updated_at': rows[0][14],
                            'created_at_time': rows[0][15],
                            'updated_at_time': rows[0][16],
                            'company_name_id': rows[0][17],
                            'user_id': rows[0][18],
                            'comment_id': rows_cmt[0][0],
                            'user_comment': rows_cmt[0][2]})

    return cmt


# In[31]:


# cmt = query_cmt('comment 2')
# for i, j in enumerate(cmt):
    
#     print(i, "-->")
#     print('='*25)
    
#     for m, n in j.items():
#         print(m, ':', n)
    
#     if i == 1:
#         break


# ---

# ## File Metadata

# In[42]:


import textract
import urllib.request
import re
import os
from collections import Counter
import operator

import xlrd
xlrd.xlsx.ensure_elementtree_imported(False, None)
xlrd.xlsx.Element_has_iter = True


# In[43]:


def fmeta(x):
    
    ### Download File ###
    
    fname = x.split('/')[-1]
    urllib.request.urlretrieve(x, fname)
    
    ############################################

    text = textract.process(fname)
    text = text.decode('utf8')

    text = text.strip('\n')
    text = text.strip('\t')
    text = text.strip('\r')

    text = re.sub("\s+" , " ", text)
    text = text.strip()
    text = text.lower()

    c = 0
    batch = ''
    batch_lst = []
    for i in text.split(' '):

        if c <= 63:
            batch = batch + ' ' + i
            c += 1

        else:
            batch_lst.append(batch.strip())
            batch = i
            c = 1

    batch_lst.append(batch.strip())
    
    if os.path.exists(fname):
        os.remove(fname)
    else:
        print("The file does not exist")

    return batch_lst


# In[47]:


# fmeta(x = 'https://backend-alpha.thesciencepark.dev/api/user/read-image/documents/Baghel_Rajkumar.pdf')
# # # lst = fmeta(x = 'kailashResume.pdf')
# # lst = fmeta(x = 'Functionality Priorities.xlsx')

# for i in lst:
#     print(i)
#     print('#'*54)


# ---

# In[ ]:


def update_fsearch():
    
    try:
        collection = Collection(name = TABLE_NAME_6)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True) #, auto_id=True)
    uid = FieldSchema(name = "uid", dtype = DataType.INT64)
    did = FieldSchema(name = "did", dtype = DataType.INT64)
    fl = FieldSchema(name = field_name_6, dtype = DataType.FLOAT_VECTOR, dim = 384)
    schema = CollectionSchema(fields = [pid, uid, did, fl], description = "File Search")
    collection = Collection(name = TABLE_NAME_6, schema = schema)
    
    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name = field_name_6, index_params = index_param)  
    
    cursor.execute("Select id, uid, did, mdata from filemeta")
    rows_pos = cursor.fetchall()
    
    lst_pid, lst_uid, lst_did, lst_fl = [], [], [], []
    for i in rows_pos:
        
        lst_pid.append(i[0])  
        lst_uid.append(i[1])
        lst_did.append(i[2])
        lst_fl.append(i[3])
    
    if len(lst_fl) != 0:
        sentence_embeddings = model.encode(lst_fl)
        sentence_embeddings = normalize(sentence_embeddings)
        print(type(sentence_embeddings))

        em = list(sentence_embeddings)
        mr = collection.insert([lst_pid, lst_uid, lst_did, em])
    else:
        print("There is no Data")


# In[ ]:


# update_fsearch()


# In[39]:


# tst = [1, 1, 2, 3, 5, 7, 8, 8, 8, 8]
# c = Counter(tst)
# print(c)

# sort = operator.itemgetter(1)
# sorted_tst = sorted(c.items(), key=sort, reverse=True)
# print(sorted_tst)


# In[ ]:


def query_fsearch(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
 
    search_skills = q
    
    embed = model.encode(search_skills)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()
    
    collection = Collection(TABLE_NAME_6)
    collection.load()
    results = collection.search(query_embeddings, field_name_6, param=search_params, limit=1000, expr=None)
    
    l = []
    for result in results[0]:
        if result.distance < 1.5:
            l.append(result.id)    
    print(l)
    
    res = collection.query(expr = "id in {}".format(l), offset = 0, limit = 100, 
                           output_fields = ["id", "uid", 'did'], consistency_level = "Strong")
    print(res)
    
    uid_lst_0, uid_lst_1, uid_lst_2 = [], [], []
    for i in res:
        
        if i['did'] == 0:
            uid_lst_0.append(i['uid'])
        if i['did'] == 1:
            uid_lst_1.append(i['uid'])
        if i['did'] == 2:
            uid_lst_2.append(i['uid'])
    
    c0 = Counter(uid_lst_0)
    c1 = Counter(uid_lst_1)
    c2 = Counter(uid_lst_2)

    sort = operator.itemgetter(1)
    sorted0 = sorted(c0.items(), key=sort, reverse=True)
    sorted1 = sorted(c1.items(), key=sort, reverse=True)
    sorted2 = sorted(c2.items(), key=sort, reverse=True)
    
    personal_doc = []
    for i in sorted0:
        d0_sql = "select upload_documents from api_personaldocumentupload where id = " + str(i[0]) + ";"
        cursor.execute(d0_sql)
        rows_d0 = cursor.fetchall()
        personal_doc.append(rows_d0)
        
    business_doc = []
    for i in sorted1:
        d1_sql = "select upload_documents from api_businessdocumentupload where id = " + str(i[0]) + ";"
        cursor.execute(d1_sql)
        rows_d1 = cursor.fetchall()
        personal_doc.append(rows_d1)
        
    lab_doc = []
    for i in sorted2:
        d2_sql = "select upload_documents from lab_profile_labdocumentupload where id = " + str(i[0]) + ";"
        cursor.execute(d2_sql)
        rows_d2 = cursor.fetchall()
        personal_doc.append(rows_d2)
    
    
    return {'personal_doc': personal_doc, 'business_doc': business_doc, 'lab_doc': lab_doc}


# ---

# In[ ]:


app = Flask(__name__)


# In[ ]:


@app.route('/updt', methods=['GET'])
def updt():
    
    try:
        update_rcmd()
        print('RCMD UPDATED')
    except:
        print('Error in RCMD UPDATED')
    
    try:
        update_stdrcmd()
        print('STDRCMD UPDATED')
    except:
        print('Error in STDRCMD UPDATED')

    try:
        update_search()
        print('SEARCH UPDATED')
    except:
        print('Error in SEARCH UPDATED')

    try:
        update_biz()
        print('BIZ UPDATED')
    except:
        print('Error in BIZ UPDATED')

    try:
        update_ppl()
        print('PPL UPDATED')
    except:
        print('Error in PPL UPDATED')

    try:
        update_cmt()
        print('CMT UPDATED')
    except:
        print('Error in CMT UPDATED')
      
    try:
        update_fsearch()
        print('Fsearch UPDATED')
    except:
        print('Error in Fsearch UPDATED')
        
    return ('', 204)

#===========================================#
    
@app.route('/get_data', methods=['GET'])
@cross_origin()
def get_data():
    
    args = request.args
    q = args.get('q')
    
    if type(q) != str:
        raise Exception("q must be a string")
        
    search = query_search(q)
    biz = query_biz(q)
    ppl = query_ppl(q)
    cmt = query_cmt(q)
    
    return {'Search': search, 'Business': biz, 'People': ppl, 'Comment': cmt}
    
@app.route('/get_rcmd', methods=['GET'])
@cross_origin()
def get_rcmd():
    
    args = request.args
    q = args.get('q')
    
    if type(q) != str:
        raise Exception("q must be a string")
        
    rcmd = query_rcmd(q)
    
    return rcmd

@app.route('/get_stdrcmd', methods=['GET'])
@cross_origin()
def get_stdrcmd():
    
    args = request.args
    q = args.get('q')
    
    if type(q) != str:
        raise Exception("q must be a string")
        
    stdrcmd = query_stdrcmd(q)
    
    return stdrcmd

@app.route('/get_fmeta', methods=['GET'])
@cross_origin()
def get_fmeta():
    
    args = request.args
    q = args.get('q')
    
    if type(q) != str:
        raise Exception("q must be a string")
        
    meta = fmeta(q)
    
    return meta

@app.route('/get_fsearch', methods=['GET'])
@cross_origin()
def get_fsearch():
    
    args = request.args
    q = args.get('q')
    
    if type(q) != str:
        raise Exception("q must be a string")
        
    meta = query_fsearch(q)
    
    return meta


# In[ ]:


if __name__ == '__main__':
    
    port = 80
    app.run(host='0.0.0.0', port=port, debug=True) # ssl_context=('cert.pem', 'key.pem')


# ---

# In[6]:


get_ipython().system('jupyter nbconvert text_search_engine_alberta.ipynb --to python')


# In[ ]:




