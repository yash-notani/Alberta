import requests
import schedule
import time

url = "https://sparkai-alpha.thesciencepark.dev/updt"

def updt(url):
	return requests.get(url)

#requests.get(url)
schedule.every(30).minutes.do(updt, url)

while True:
    schedule.run_pending()
    time.sleep(1)
