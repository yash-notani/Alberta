#!/usr/bin/env python
# coding: utf-8

# In[1]:


# !wget https://raw.githubusercontent.com/milvus-io/milvus/master/deployments/docker/standalone/docker-compose.yml -O docker-compose.yml
# !sudo docker-compose up -d


# In[308]:


from pymilvus import connections, utility
import psycopg2

from pymilvus import Collection, CollectionSchema, FieldSchema, DataType

from sentence_transformers import SentenceTransformer
import pandas as pd
from sklearn.preprocessing import normalize

from pymilvus import Collection, CollectionSchema, FieldSchema, DataType

from flask import Flask, request
from flask_cors import CORS, cross_origin

from tqdm import tqdm

from OpenSSL import SSL


# ---

# In[397]:


connections.connect(host='34.134.178.153', port='19530')
conn = psycopg2.connect(database="usapendingdatabase", host='34.172.71.236', port='5432', user='postgres', password='Vijay@8149') # alpha
print("CONNECTION ====",conn)

TABLE_NAME = "T1"
field_name = "f1"

cursor = conn.cursor()
model = SentenceTransformer('paraphrase-mpnet-base-v2')


# In[398]:


var = str(range(100001))
len(var)


# In[399]:


cursor.execute("Select * FROM test2_usa_table_filter LIMIT 0")
colnames = [desc[0] for desc in cursor.description]
colnames


# In[389]:


cursor.execute("Select * FROM test2_usa_table_filter LIMIT 0")
colnames = [desc[0] for desc in cursor.description]
colnames


# In[412]:


# cursor.execute("DELETE FROM test2_usa_table_filter WHERE uid = 1;")
sql = "select * from test2_usa_table_filter;"
cursor.execute(sql)
rows = cursor.fetchall()
rows


# In[393]:


cursor.execute("ALTER TABLE test2_usa_table_filter DROP COLUMN index;")
cursor.execute("ALTER TABLE test2_usa_table_filter DROP COLUMN uid;")
cursor.execute("Select * FROM test2_usa_table_filter LIMIT 0")
colnames = [desc[0] for desc in cursor.description]
colnames


# In[394]:


cursor.execute("ALTER TABLE test2_usa_table_filter ADD COLUMN uid SERIAL NOT NULL PRIMARY KEY;")
sql = "select * from test2_usa_table_filter;"
cursor.execute(sql)
rows = cursor.fetchall()
print(rows[-1])


# In[396]:


conn.commit()


# In[338]:


# for i in range(100001):
#     cursor.execute("INSERT INTO test2_usa_table_filter(uid) VALUES ({});".format(i))
# sql = "select * from test2_usa_table_filter;"
# cursor.execute(sql)
# rows = cursor.fetchall()
# print(rows[-1])


# In[312]:


# sql = "UPDATE test2_usa_table_filter SET uid = %s;", var
# sql = "SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'test2_usa_table_filter';"
cursor.execute(sql)#"INCERT INTO test2_usa_table_filter() SET uid = {};".format(var))
rows = cursor.fetchall()


# In[314]:


rows[0]


# ---

# In[415]:


def update():
    
    try:
        collection = Collection(name = TABLE_NAME)
        collection.drop()
    except:
        pass
    
    pid = FieldSchema(name = "id", dtype = DataType.INT64, is_primary = True)
    desc = FieldSchema(name = field_name, dtype = DataType.FLOAT_VECTOR, dim = 768)
    schema = CollectionSchema(fields = [pid, desc], description = "example collection")
    collection = Collection(name = TABLE_NAME, schema = schema)

    index_param = {
            "metric_type":"L2",
            "index_type":"IVF_SQ8",
            "params":{"nlist":1024}
        }
    collection.create_index(field_name=field_name, index_params=index_param)

    sql = "select contract_transaction_unique_key, after_preprocess_sentence from test2_usa_table_filter;"
    cursor.execute(sql)
    rows_pos = cursor.fetchall()
    
    lst_pid = list(range(1, len(rows_pos)))
    print(lst_pid[0], '==>', lst_pid[-1])
    
    c = 0
    lst_desc = []
    for i, j in tqdm(rows_pos):
        
        if c == 0:
            c += 1
            continue
        
        
        lst_desc.append(j.strip())

    sentence_embeddings = model.encode(lst_desc)
    sentence_embeddings = normalize(sentence_embeddings)
    print(type(sentence_embeddings))

    em = list(sentence_embeddings)
    print(len(em))
    mr = collection.insert([lst_pid, em])
    
#     return lst_pid


# In[416]:


get_ipython().run_cell_magic('time', '', 'update()\n')


# ---

# In[417]:


search_params = {"metric_type": "L2", "params": {"nprobe": 10}}


# In[424]:


# query_embeddings = []
embed = model.encode('ledger')
embed = embed.reshape(1,-1)
embed = normalize(embed)
query_embeddings = embed.tolist()

collection = Collection("T1")      # Get an existing collection.
collection.load()
results = collection.search(query_embeddings, field_name, param=search_params, limit=10, expr=None)


# In[425]:


for i in results[0]:
    print(i.id, '==>', rows[i.id])


# In[ ]:


def query(q = ''):
    
    if type(q) != str:
        raise Exception("q must be a string")
        
    if utility.has_collection("T1") == False:
        raise Exception("Milvus collection not available")
 
    search = q.strip()

    embed = model.encode(search)
    embed = embed.reshape(1,-1)
    embed = normalize(embed)
    query_embeddings = embed.tolist()

    collection = Collection("T1")      # Get an existing collection.
    collection.load()
    results = collection.search(query_embeddings, field_name, param=search_params, limit=51, expr=None)
    
    sql = "select contract_transaction_unique_key, prime_award_base_transaction_description \
           from test2_usa_table_filter;"
    cursor.execute(sql)
    rows = cursor.fetchall()

    recommendation = []
    for result in results[0]:

#         sql = "select * from challenge_creator_challengestatement where id = " + str(result.id) + ";"
#         cursor.execute(sql)
#         rows = cursor.fetchall()
        
#         get_user_name = "select username from api_user where id ="+ str(rows[0][12])+";"
#         cursor.execute(get_user_name)
#         fetch_user_name = cursor.fetchall()
#         fetch_user_name = fetch_user_name[0][0]
        
#         if rows[0][11] is not None:
#             get_company_name = "select company_name from api_businessinformation where id ="+ str(rows[0][11])+";"
#             cursor.execute(get_user_name)
#             fetch_company_name = cursor.fetchall()
#             fetch_company_name = fetch_company_name[0][0]
#         else:
#             fetch_company_name = None

        if len(rows):
            recommendation.append({'id' : rows[0][0], 
                                   'challenge_title': rows[0][1],
                                   'challenge_description': rows[0][2],
                                   'challenge_location': rows[0][3],
                                   'skills': rows[0][4],
                                   'status_type': rows[0][5],
                                   'post_type': rows[0][6],
                                   'is_active': rows[0][7],
                                   'is_archieve': rows[0][8],
                                   'created_at': rows[0][9],
                                   'updated_at': rows[0][10],
                                   'company_name_id': rows[0][11],
                                   'user_id': rows[0][12],
                                   'user_name': fetch_user_name,
                                   'company_name': fetch_company_name})

    return recommendation


# In[ ]:


# rcm = query('ai')
# for i, j in enumerate(rcm):
#     print(i, "-->", j['skills'])


# ---

# In[ ]:


app = Flask(__name__)

@app.route('/updt', methods=['GET'])
def updt():
    update() 
    return ('', 204)
    
@app.route('/get_rcmd', methods=['GET'])
@cross_origin()
def get_rcmd():
    
    args = request.args
    q = args.get('q')
    
    if type(q) != str:
        raise Exception("q must be a string")
    
    return query(q)

if __name__ == '__main__':
    
    port = 80
    app.run(host='0.0.0.0', port=port, debug=True)


# In[ ]:


get_ipython().system('jupyter nbconvert text_search_engine_alberta.ipynb --to python')


# In[ ]:




