from text_search_engine_alberta_Copy1 import app

application = app
